﻿using System.Configuration;
using System.Web.Mvc;
using System.Web.Routing;

namespace ASP.net_MVC_Reference_Architecture
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            // Handling contact form submissions
            routes.MapRoute(
                name: "ContactThanks",
                url: ConfigurationManager.AppSettings["CrownPeak:ContactFormEntry"],
                defaults: new
                {
                    controller = "ContactForm",
                    action = "Submit"
                }
            );

            // CrownPeak catch-all
            routes.MapRoute(
                name: "CrownPeakPage",
                url: "{*page}",
                defaults: new
                {
                    controller = "CrownPeakPage",
                    action = "Page"
                }
            );
        }
    }
}