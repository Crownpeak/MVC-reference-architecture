﻿using System.Web;
using System.Web.Mvc;

namespace ASP.net_MVC_Reference_Architecture
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}