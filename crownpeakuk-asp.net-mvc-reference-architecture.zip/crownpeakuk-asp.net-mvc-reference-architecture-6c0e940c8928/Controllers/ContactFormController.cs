﻿using System;
using System.Configuration;
using System.Text;
using System.Web.Mvc;
using NLog;

namespace ASP.net_MVC_Reference_Architecture.Controllers
{
    public class ContactFormController : Controller
    {
        /// <summary>
        /// Create class-scoped logging static variable, use Logger.Log() to call.
        /// </summary>
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        [HttpPost]
        public ActionResult Submit(FormCollection formCollection)
        {
            try
            {
                // TODO: Do some exciting stuff with the data that has been submitted to the form
                var formData = new StringBuilder();
                foreach (var item in formCollection)
                {
                    formData.Append(string.Format("{0}\n", item));
                }
                Logger.Log(LogLevel.Info, formData);

                return
                    Redirect(
                        ConfigurationManager.AppSettings["CrownPeak:ContactFormThanks"]);
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, ex);
                return
                    Redirect(
                        String.Format(
                            "{0}?error=1",
                            ConfigurationManager.AppSettings["CrownPeak:ContactFormEntry"]));
            }
        }
    }
}