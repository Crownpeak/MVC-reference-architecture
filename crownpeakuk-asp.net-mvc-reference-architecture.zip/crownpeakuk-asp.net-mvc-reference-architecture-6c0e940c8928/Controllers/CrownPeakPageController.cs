﻿using System;
using System.Configuration;
using System.Web.Mvc;
using NLog;

namespace ASP.net_MVC_Reference_Architecture.Controllers
{
    public class CrownPeakPageController : Controller
    {
        /// <summary>
        /// Create class-scoped logging static variable, use Logger.Log() to call.
        /// </summary>
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// The 'catch-all' controller for the CrownPeak MVC application.
        /// Examines the request url and looks for the corresponding .cshtml file located on the filesystem.
        /// </summary>
        /// <returns>Intended view if .cshtml file located on disk, custom 404 page if not. In the event of error, logs and returns custom 500 page.</returns>
        public ActionResult Page()
        {
            try
            {
                if (Request.Url == null) return null;
                if (Request.ApplicationPath != null)
                {
                    var absolutePath = Request.Url.AbsolutePath.Replace(Request.ApplicationPath, "");
                    if (!absolutePath.StartsWith("/")) absolutePath = "/" + absolutePath;
                    if (absolutePath == "/") absolutePath = ConfigurationManager.AppSettings["CrownPeak:DefaultHome"];
                    var viewFile = Shared.MvcUtils.GetViewFileLocation(absolutePath);
                    if (System.IO.File.Exists(Server.MapPath(viewFile))) return View(viewFile);
                }
                //TODO: Need to override default IIS handling of 404 pages in order to successfully use 404 Response.StatusCode
                //Response.StatusCode = 404;
                return View(Shared.MvcUtils.GetViewFileLocation(ConfigurationManager.AppSettings["CrownPeak:Default404"]));
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, ex);
                return View(Shared.MvcUtils.GetViewFileLocation(ConfigurationManager.AppSettings["CrownPeak:Default500"]));
            }
        }
    }
}