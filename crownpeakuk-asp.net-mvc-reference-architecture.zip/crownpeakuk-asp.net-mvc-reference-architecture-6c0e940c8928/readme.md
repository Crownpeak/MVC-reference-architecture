ASP.net MVC Reference Architecture
==============

Reference architecture for ASP.net MVC supported deployments within CrownPeak.
