﻿using System;
using System.Configuration;
using System.Text;
using NLog;

namespace ASP.net_MVC_Reference_Architecture.Shared
{
    public static class MvcUtils
    {
        /// <summary>
        /// Create class-scoped logging static variable, use Logger.Log() to call.
        /// </summary>
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Return 'on disk' location for provided request url.
        /// </summary>
        /// <param name="viewFile">The requested url.</param>
        /// <returns>'on disk' location for provided request url.</returns>
        public static string GetViewFileLocation(string viewFile)
        {
            try
            {
                return
                    new StringBuilder().Append(ConfigurationManager.AppSettings["CrownPeak:ViewsRoot"])
                        .Append(viewFile)
                        .Append(ConfigurationManager.AppSettings["CrownPeak:ViewsFileExtension"])
                        .ToString();
            }
            catch (Exception ex)
            {
                Logger.Log(LogLevel.Error, ex);
                return String.Empty;
            }
        }
    }
}